/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dat;

import db.DBUtiliz;
import java.sql.*;
import java.util.LinkedList;
import java.util.List;
import java.util.logging.Logger;
import java.util.logging.Level;
import model.villageolympique;

/**
 *
 * @author Owner
 */
public class Data {
    public void addNew(villageolympique vo){
        try{
            PreparedStatement ps = DBUtiliz.getPreparedStatement("insert into public.villageolympique values(?,?,?)");
            ps.setString(1, vo.getAddress());
            ps.setString(2, vo.getCapacite());
            ps.setString(3, vo.getTelephone());
            
           
            ps.executeUpdate();
        }
        catch(SQLException ex){
            Logger.getLogger(Data.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
        public static List<villageolympique> getAll(){
            List<villageolympique> ls = new LinkedList<>();
            
            try{
                ResultSet rs;
                rs = DBUtiliz.getPreparedStatement("select * from public.villageolympique").executeQuery();
                while(rs.next()){
                    villageolympique vo = new villageolympique(rs.getString(1),rs.getString(2),rs.getString(3));
                    ls.add(vo);
                }
            }
            catch(SQLException ex){
            Logger.getLogger(Data.class.getName()).log(Level.SEVERE, null, ex);
            }
            return ls;
        }
        public static List<villageolympique> getVillageById(String address){
            List<villageolympique> ls = new LinkedList<>();
            String sql = "select * from public.villageolympique where address like '%" + address + "%'";
            try{
                ResultSet rs;
                rs = DBUtiliz.getPreparedStatement(sql).executeQuery();
                while(rs.next()){
                    villageolympique vo = new villageolympique(rs.getString(1),rs.getString(2),rs.getString(3));
                    ls.add(vo);
                }
            }
            catch(SQLException ex){
            Logger.getLogger(Data.class.getName()).log(Level.SEVERE, null, ex);
            }
            return ls;
        }
        
        public void edit(String address, String capacite, String telephone) throws SQLException{
            String sql = "update public.villageolympique set address = ?,capacite = ?,telephone = ?";
            PreparedStatement ps;
            ps = DBUtiliz.getPreparedStatement(sql);
            ps.setString(1, address);
            ps.setString(2, capacite);
            ps.setString(3, telephone);
            
            ps.executeUpdate();
        }
        
        public void delete(String address) throws SQLException{
            String sql = "delete from public.villageolympique where address = ?";
            PreparedStatement ps;
            ps = DBUtiliz.getPreparedStatement(sql);
            ps.setString(1, address);
            ps.executeUpdate();
        }
}
