/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dat;

import db.DBUtiliz;
import java.sql.*;
import java.util.LinkedList;
import java.util.List;
import java.util.logging.Logger;
import java.util.logging.Level;
import model.villageolympique;

/**
 *
 * @author Owner
 */
public class Data {
    public void addNew(villageolympique vo){
        try{
            PreparedStatement ps = DBUtiliz.getPreparedStatement("insert into public.villageolympique values(?,?,?)");
            ps.setString(1, vo.getCapacite());
            ps.setString(2, vo.getTelephone());
            ps.setString(3, vo.getAddress());
            ps.executeUpdate();
        }
        catch(SQLException ex){
            Logger.getLogger(Data.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
        public static List<villageolympique> getAll(){
            List<villageolympique> ls = new LinkedList<>();
            try{
                ResultSet rs;
                rs = DBUtiliz.getPreparedStatement("select * from public.villageolympique").executeQuery();
                while(rs.next()){
                    villageolympique vo = new villageolympique(rs.getString(1),rs.getString(2),rs.getString(3));
                    ls.add(vo);
                }
            }
            catch(SQLException ex){
            Logger.getLogger(Data.class.getName()).log(Level.SEVERE, null, ex);
            }
            return ls;
        }
    
}
